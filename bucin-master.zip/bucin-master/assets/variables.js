export default {
  nicknames: ["Nick", "Cewe", "Akan", "Di", "Random"],
  greetings: {
    evening: "Good Evening",
    afternoon: "Good Afternoon",
    day: "Good Day",
    morning: "Good Morning",
    night: "Good Night"
  }
};
