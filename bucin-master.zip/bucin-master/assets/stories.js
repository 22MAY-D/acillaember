export default [
  "Teks pertama",
  "Teks kedua",
  "Teks ke - n",
  "Aku sayang kamu!"
];
